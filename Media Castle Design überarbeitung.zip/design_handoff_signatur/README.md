# Handoff: Media Castle — Signatur „visualized by media castle"

## Overview
Eine Marken-Signatur für Media Castle: der Schriftzug **„visualized by media castle"** mit dem Burg-Wappen. Zwei Einsatzzwecke:
1. **Footer-Signatur** am unteren Rand der eigenen Website.
2. **Foto-Badge** / Credit, das auf Kunden-Websites platziert wird (auch als Glas-Panel über einem Foto). Immer klickbar, verlinkt auf `https://media-castle.de`.

## About the Design Files
Die Datei in `reference/` ist eine **Design-Referenz in HTML** (ein Prototyp, der Aussehen und Verhalten zeigt) — **kein Produktionscode zum 1:1-Kopieren**. Aufgabe ist, diese Signatur im Ziel-Projekt mit dessen bestehenden Mustern/Bibliotheken nachzubauen (React/Vue/plain HTML etc.). Für einfaches Einbetten liegt in `snippet.html` bereits fertiger, framework-freier Code, den man direkt übernehmen kann.

## Fidelity
**High-fidelity (hifi)** — finale Farben, Typografie und Abstände sind unten exakt dokumentiert. Pixelgenau nachbauen.

## Assets
Im Ordner `assets/`:
- `mc-logo-navy.png` — Burg-Wappen in Marken-Navy `#041833`, transparenter Hintergrund (1600×1600). Für helle Hintergründe.
- `mc-logo-white.png` — dasselbe Wappen in Weiß, transparent. Für dunkle Hintergründe / Fotos.
- `mc-logo.svg` — Original-SVG des Logos (mit weißem Kreis-Rahmen).

**Empfehlung fürs Repo:** ein sauberes einfarbiges SVG des Wappens ist ideal (skaliert verlustfrei, per `currentColor` einfärbbar). Bis dahin funktionieren die transparenten PNGs überall.

## Design Tokens
| Token | Wert |
|---|---|
| Marken-Navy | `#041833` |
| Weiß | `#ffffff` |
| Label-Farbe (auf hell) | `rgba(4,24,51,.55)` |
| Label-Farbe (auf dunkel) | `rgba(255,255,255,.6)` |
| Schrift | **Poppins** (Google Fonts), Fallback `system-ui, sans-serif` |
| Gewichte | 400 (Label), 600 (Wortmarke) |
| Radius (Badge/Glas) | `12px` |

## Anatomie der Signatur
Von links nach rechts, alles vertikal zentriert:
1. **Wappen** (Logo-Bild), quadratisch. Größe skaliert mit der Schrift.
2. **Label** „visualized by" — Poppins 400, Farbe gedimmt (siehe Tokens).
3. **Wortmarke** „media castle" — Poppins 600, volle Farbe (Navy auf hell, Weiß auf dunkel).

Der ganze Block ist ein einzelner `<a>` mit `display:inline-flex; align-items:center`. Alle Teile immer **komplett kleingeschrieben**.

### Varianten (im Referenz-HTML gezeigt)
- **Horizontal einzeilig** (Standard, empfohlen für Footer & Badge): Logo · „visualized by" · „media castle" in einer Zeile.
- **Horizontal gestapelt**: Logo links, Label über Wortmarke (zweizeilig).
- **Nur Text** / **Nur Wappen** (Watermark).
- Je einmal auf **Weiß** und auf **Navy**.
- **Glas-Panel über Foto**: Badge unten rechts, `backdrop-filter: blur(12px)`, halbtransparenter Hintergrund + heller Rand (siehe `snippet.html`).

### Größen-Referenz (horizontal, einzeilig)
| Größe | font-size | Logo | gap |
|---|---|---|---|
| S (Footer klein) | 13px | 18px | 8px |
| M | 17px | 26px | 10px |
| L | 22px | 34px | 12px |

## Interactions & Behavior
- Gesamter Block ist ein Link: `href="https://media-castle.de"`, `target="_blank"`, `rel="noopener"`.
- Kein `text-decoration`. Optional dezenter Hover (z.B. `opacity:.85`).
- Glas-Panel: absolut positioniert `right:16px; bottom:16px` im Foto-Container (`position:relative; overflow:hidden`).

## Varianten-Übersicht (so heißen die Snippets in `snippet.html`)
Sag Claude Code einfach: „Nimm Variante **V4** aus `snippet.html`".

| ID | Name | Einsatz |
|---|---|---|
| **V1** | Footer horizontal · hell | Einzeilig, auf hellem Hintergrund (Footer heller Seiten) |
| **V2** | Footer horizontal · dunkel | Einzeilig, weiß, auf dunklem Hintergrund |
| **V3** | Foto-Badge · Glas-Panel | Über einem Foto/Hero, unten rechts, mit Blur-Glas |
| **V4** | Highlight-Stil · hell | Logo groß + „angestrichenes" Label & Wortmarke, auf Weiß |
| **V5** | Highlight-Stil · dunkel | Wie V4, weiß, auf Navy `#041833` |
| **V6** | React-Komponente | Deckt V1/V2/V4/V5 über Props `variant` + `highlight` ab |

## Files
- `snippet.html` — fertige, benannte Snippets **V1–V6** zum Kopieren.
- `reference/Media Castle Signatur.dc.html` — vollständige visuelle Design-Referenz mit allen Varianten (im Browser öffnen).
- `assets/` — Logo-Dateien (navy, weiß, SVG).
