
import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop.jsx';
import HomePage from './pages/HomePage.jsx';
import NewsPage from './pages/NewsPage.jsx';
import ClubPage from './pages/ClubPage.jsx';
import GroupsPage from './pages/GroupsPage.jsx';
import TrainingTimesPage from './pages/TrainingTimesPage.jsx';
import PhotosPage from './pages/PhotosPage.jsx';
import ContactPage from './pages/ContactPage.jsx';
import ImprintPage from './pages/ImprintPage.jsx';
import PrivacyPage from './pages/PrivacyPage.jsx';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/news" element={<NewsPage />} />
        <Route path="/club" element={<ClubPage />} />
        <Route path="/groups" element={<GroupsPage />} />
        <Route path="/training-times" element={<TrainingTimesPage />} />
        <Route path="/photos" element={<PhotosPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/imprint" element={<ImprintPage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="*" element={
          <div className="min-h-screen bg-background flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-6xl font-bold text-primary mb-4">404</h1>
              <p className="text-xl text-muted-foreground mb-8">Seite nicht gefunden</p>
              <a
                href="/"
                className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all duration-200 active:scale-[0.98] font-medium"
              >
                Zurück zur Startseite
              </a>
            </div>
          </div>
        } />
      </Routes>
    </Router>
  );
}

export default App;
