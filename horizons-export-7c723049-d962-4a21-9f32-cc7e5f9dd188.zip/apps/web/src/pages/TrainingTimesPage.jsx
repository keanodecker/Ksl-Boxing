
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import TrainingTimeTable from '@/components/TrainingTimeTable.jsx';

const TrainingTimesPage = () => {
  const schedules = [
    {
      id: 'competition',
      group: 'Wettkampfmannschaft',
      schedule: [
        { day: 'Montag', time: '18:00 - 20:00 Uhr' },
        { day: 'Mittwoch', time: '18:00 - 20:00 Uhr' },
        { day: 'Freitag', time: '18:00 - 20:00 Uhr' },
        { day: 'Samstag', time: '10:00 - 12:00 Uhr', note: 'Sparring' }
      ]
    },
    {
      id: 'fitness',
      group: 'Fitness-Boxen',
      schedule: [
        { day: 'Dienstag', time: '19:00 - 20:30 Uhr' },
        { day: 'Donnerstag', time: '19:00 - 20:30 Uhr' },
        { day: 'Samstag', time: '09:00 - 10:30 Uhr' }
      ]
    },
    {
      id: 'women',
      group: 'Frauenboxen',
      schedule: [
        { day: 'Dienstag', time: '18:00 - 19:30 Uhr' },
        { day: 'Donnerstag', time: '18:00 - 19:30 Uhr' }
      ]
    },
    {
      id: 'youth',
      group: 'Jugendtraining',
      schedule: [
        { day: 'Montag', time: '16:30 - 18:00 Uhr' },
        { day: 'Mittwoch', time: '16:30 - 18:00 Uhr' },
        { day: 'Freitag', time: '16:30 - 18:00 Uhr' }
      ]
    },
    {
      id: 'kids',
      group: 'Kindertraining',
      schedule: [
        { day: 'Dienstag', time: '16:00 - 17:00 Uhr' },
        { day: 'Donnerstag', time: '16:00 - 17:00 Uhr' }
      ]
    },
    {
      id: 'beginners',
      group: 'Anfängertraining',
      schedule: [
        { day: 'Montag', time: '19:00 - 20:30 Uhr' },
        { day: 'Mittwoch', time: '19:00 - 20:30 Uhr' }
      ]
    },
    {
      id: 'open',
      group: 'Offenes Training',
      schedule: [
        { day: 'Dienstag', time: '20:30 - 22:00 Uhr' },
        { day: 'Donnerstag', time: '20:30 - 22:00 Uhr' },
        { day: 'Samstag', time: '14:00 - 16:00 Uhr' }
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Trainingszeiten – KSL Boxing Lahr</title>
        <meta name="description" content="Übersicht aller Trainingszeiten bei KSL Boxing Lahr. Finden Sie die passenden Zeiten für Ihre Trainingsgruppe." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />

        <main className="py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Trainingszeiten</h1>
              <p className="text-xl text-muted-foreground mb-16 leading-relaxed max-w-3xl">
                Hier finden Sie eine Übersicht aller Trainingszeiten. Bitte beachten Sie, dass sich Zeiten ändern können. Bei Fragen kontaktieren Sie uns gerne.
              </p>

              <div className="space-y-8">
                {schedules.map((item, index) => (
                  <div key={item.id} id={item.id} className="scroll-mt-20">
                    <TrainingTimeTable {...item} />
                  </div>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="mt-16 p-8 bg-secondary rounded-2xl border border-border"
              >
                <h2 className="text-2xl font-semibold mb-4">Wichtige Hinweise</h2>
                <ul className="space-y-3 text-lg text-secondary-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold mt-1">•</span>
                    <span>Bitte erscheinen Sie 10 Minuten vor Trainingsbeginn, um sich umzuziehen und aufzuwärmen.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold mt-1">•</span>
                    <span>An Feiertagen und in den Schulferien können abweichende Zeiten gelten.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold mt-1">•</span>
                    <span>Probetraining ist nach vorheriger Anmeldung jederzeit möglich.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold mt-1">•</span>
                    <span>Bei Krankheit oder Verletzung bitte vor dem Training mit dem Trainer sprechen.</span>
                  </li>
                </ul>
              </motion.div>
            </motion.div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default TrainingTimesPage;
